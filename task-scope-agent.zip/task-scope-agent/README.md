# 任务边界双层工作流

用 `task-scope` 交办任务后，Skill 负责前台筛查，把标准案件包交给 `task_scope_judge` Agent 隔离裁定。确认可开工的实施任务由主助手在同一轮接着完成。

```text
用户要求 / 附件材料
        |
        v
$task-scope Skill
来源分离、脱敏、完整性检查、案件包封装
        |
        v
task_scope_judge Agent
无父对话、无工具、无应用、无插件、无记忆
        |
        v
Skill 校验裁定，主助手按任务意图实施或报告结论
```

## 安装位置

- Skill 文件夹：`~/.codex/skills/task-scope/`
- Agent 配置：`~/.codex/agents/task_scope_judge.toml`

Skill 也可以通过 Codex 的“设置 → 插件 → 技能 → 添加 → 浏览目录”选择本包中的 `task-scope` 文件夹。Agent 配置仍需单独放入 `~/.codex/agents/`。安装后重新打开 Codex 或新建对话，使配置重新加载。

## 使用

最短用法：

> `task-scope 清理动态配置中的草稿概览`

如果上一条消息已经说清任务，只需再发：

> `task-scope`

`$task-scope`、“调用 task-scope”和在对话中引用 `@task_scope_judge` 也等效。通过引用调用时，主对话会重新读取当前 Skill，并用裁定结果生成对话回复。Skill 会从当前对话自动识别事项，并判断这是新任务定义、追加变更还是交付验收；用户不需要写 mode、来源编号或 JSON。

如果你交办了实施，补齐待确认问题后，Skill 会继续裁定。结果确认可以开工时，主助手会简短说明实施范围，随即开始做并验证。只要求裁定或验收时，收到的是相应的结论。

只有 CHANGE_REVIEW / DELIVERY_REVIEW 所需的当前基线版本确实不在对话中时，Skill 才会追问版本号，不会要求重新描述整份任务。

下面这些完整写法仍然支持，但不是必需格式。

新任务：

> 使用 `$task-scope` 梳理下面任务的边界：后台商品列表支持按商品名称关键词筛选，清空后恢复默认列表。沿用现有权限和分页，在测试环境验收。

追加要求：

> 使用 `$task-scope` 对照已确认的任务单版本 `v3`，裁定这三项追加要求：补清空条件测试、导出 Excel、让运营团队使用搜索。

CHANGE_REVIEW 使用四类结果：

- `范围内`（`IN_SCOPE`）：原范围明确包含的事项，以及能直接回指某条已确认交付物或验收条目的常规步骤。裁定须引用该条目的来源编号。常规步骤须遵守已有约束，且不得新增业务规则、权限、数据范围、环境或外部动作。
- `需变更`（`CHANGE_REQUIRED`）：扩大范围或改变交付，但没有直接命中已确认排除项或约束。
- `范围外`（`OUT_OF_SCOPE`）：与 `non_goals` 或已确认约束直接冲突，且没有较新的用户指令明确覆盖旧限制。
- `待确认`（`NEEDS_CONFIRMATION`）：常规步骤缺少对应的已确认交付或验收依据，或缺失事实可能影响业务规则、权限、数据范围、环境、交付物或验收条件。

只有确认上述六项和范围裁定都不受影响时，才可继续裁定该项，并在对应裁定中写明暂用假设。

每个候选项在内部 `items` 中单独输出一个对象，`item_id` 使用原始 `candidate_item.id`，`category` 使用上面四类对应的稳定枚举。每项都固定包含 `source_ids`、`reason`、`impact` 和 `next_step`。找不到可用来源时，该项使用 `NEEDS_CONFIRMATION`，并说明缺少的依据。Skill 会把这些字段转换成用户可读的逐项 Markdown，不会直接展示内部对象或来源编号。

案件包始终包含 `non_goals`。在 CHANGE_REVIEW 和 DELIVERY_REVIEW 中，前台必须先检查已确认基线：有明确排除项时列表必须非空；确实没有时可传空数组；基线不完整时则把无法确认排除项的事实写入 `unresolved_facts`。基线已经写明排除项但 `non_goals` 为空时，隔离 Agent 会拒绝受理。

CHANGE_REVIEW 和 DELIVERY_REVIEW 还要求 `confirmed_baseline.baseline_version` 非空。每次裁定都会显示并绑定这个版本；已确认范围发生变化后必须生成新版本号，不能在同一版本下改写内容。缺少版本号、混入多个无法判定新旧的版本，或仅凭消息顺序推断新旧时，隔离 Agent 会拒绝受理。

Skill 调用隔离 Agent 时只发送一个裸 CASE_PACKET_V1 JSON 对象。对象前后不得出现提示语、解释、代码围栏、原始附件、对话历史或第二个 JSON 对象；顶层也不允许 `conversation_history`、`raw_context`、`attachments` 等额外字段。Agent 会先对整条消息做格式检查，违规时返回结构化 `UNABLE_TO_JUDGE`，不会从混合文本里抽取案件包做部分判断。

Skill 在发送前执行模式自检：DEFINE 要求 `confirmed_baseline=null`；CHANGE_REVIEW 要求有效基线和非空 `candidate_items`；DELIVERY_REVIEW 要求有效基线和非空 `acceptance_evidence`。前台漏映射时先修正，用户未提供时停止并追问，不会把残缺案件包交给 Agent 后批量输出“待确认”。Agent 也会复核这些条件，防止手动调用绕过前台。

主对话通过 Skill 调用内部裁定 Agent。如果只安装 Skill 而没有安装 Agent，Skill 会停止并报告缺少隔离裁定组件，不会自行给出结论。

## 个性化指令与端到端指标

可将 [三条指标规则](docs/codex-instructions.md) 合并到 Codex 的「设置 → 个性化 → Codex 指令」。为追加事项测速或复盘时，规则会自动应用。当前对话已有明确的追加事项时，可以直接发送下面这句话。

> task-scope，审查这条追加要求，并记录端到端指标。

记录口径和明细模板见 [追加事项端到端指标](task-scope/references/metrics.md)。组件职责和使用示例见 [任务边界整合包报告](docs/任务边界整合包报告.docx)。

## 裁定结果

日常对话只用简洁 Markdown 说明整体结论、状态、每项裁定、依据、影响、下一步和需要确认的问题。默认不显示 JSON、协议字段、内部枚举、JSON 路径或来源编号。只有用户明确要求查看原始数据时，才可以提供已通过校验的 JSON。

隔离 Agent 的内部成功和失败结果都使用一个裸 `TASK_SCOPE_RESULT_V1` JSON 对象，不带 Markdown 或对象外说明。该对象只在 Skill 内部解析和校验，不是用户交付格式。顶层固定包含 `result_version`、`verdict`、`mode`、`baseline_version`、`status`、`items`、`missing_fields`、`reason` 和 `questions`。顶层 `verdict` 只表示整份结果是已完成裁定还是无法裁定；每个事项的具体结论由 `items[].category` 表示。

以下 JSON 仅用于内部协议调试。正常 CHANGE_REVIEW 示例：

```json
{
  "result_version": "TASK_SCOPE_RESULT_V1",
  "verdict": "ADJUDICATED",
  "mode": "CHANGE_REVIEW",
  "baseline_version": "v3",
  "status": null,
  "items": [
    {
      "item_id": "I1",
      "category": "IN_SCOPE",
      "source_ids": ["U2", "C1"],
      "reason": "该项直接支撑已确认验收条件。",
      "impact": "不新增业务规则、权限、数据范围、环境或外部动作。",
      "next_step": "按 v3 继续执行并保留验证证据。"
    }
  ],
  "missing_fields": [],
  "reason": "已按基线 v3 完成逐项裁定。",
  "questions": []
}
```

无法受理示例：

```json
{
  "result_version": "TASK_SCOPE_RESULT_V1",
  "verdict": "UNABLE_TO_JUDGE",
  "mode": null,
  "baseline_version": null,
  "status": null,
  "items": [],
  "missing_fields": ["$"],
  "reason": "本轮消息不是单一裸 JSON 对象。",
  "questions": []
}
```

Skill 会完整解析并校验返回对象。字段缺失、枚举错误、来源编号无效、候选项没有一一对应或混入对象外文字时，以 `UNABLE_TO_JUDGE` 和 `missing_fields: ["$agent_result"]` 记录内部协议错误，并在聊天中简短说明无法裁定的原因。
