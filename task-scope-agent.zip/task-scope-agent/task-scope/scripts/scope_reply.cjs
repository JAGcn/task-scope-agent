// Read the current turn's isolated judge and pass its exact reply to the formatter.
function unpack(result) {
  if (result.isError) return {};
  return result.structuredContent ?? JSON.parse(result.content[0].text);
}

function shellQuote(value) {
  return "'" + value.replace(/'/g, "'\\''") + "'";
}

module.exports = async function scopeReply(tools, taskName, context, raw = false) {
  const identity = await tools.exec_command({ cmd: 'printf %s "$CODEX_THREAD_ID"' });
  const threadId = identity.output.trim();
  if (identity.exit_code !== 0 || !/^[0-9a-f-]{36}$/i.test(threadId)) {
    return { state: "unavailable" };
  }

  const caller = unpack(await tools.mcp__codex_app__read_thread({
    threadId, turnLimit: 1, includeOutputs: false, maxOutputCharsPerItem: 80,
  }));
  const matchesName = path =>
    taskName.includes("/") ? path === taskName : path?.split("/").at(-1) === taskName;
  const judges = (caller.turns?.[0]?.items ?? []).filter(item =>
    item.type === "subAgentActivity" && item.kind === "started" &&
    matchesName(item.agentPath) && item.agentThreadId
  );
  if (judges.length !== 1) return { state: "unavailable" };

  const judgeId = judges[0].agentThreadId;
  const snapshot = unpack(await tools.mcp__codex_app__wait_threads({
    targets: [{ threadId: judgeId }], timeoutMs: 40000,
  }));
  const latest = snapshot.polls?.find(poll => poll.thread?.id === judgeId)?.latestTurn;
  if (latest?.status !== "completed") {
    return { state: snapshot.timedOut ? "pending" : "unavailable" };
  }

  const judge = unpack(await tools.mcp__codex_app__read_thread({
    threadId: judgeId, turnLimit: 1, includeOutputs: false, maxOutputCharsPerItem: 20000,
  }));
  const turn = judge.turns?.find(item => item.id === latest.id);
  const replies = (turn?.items ?? []).filter(item =>
    item.type === "agentMessage" && (item.phase === "final_answer" || item.phase === "final")
  );
  if (replies.length !== 1 || typeof replies[0].text !== "string") {
    return { state: "unavailable" };
  }

  const payload = JSON.stringify({ context, response: replies[0].text, raw });
  const reply = await tools.exec_command({
    cmd: `printf %s ${shellQuote(payload)} | python3 -I "$HOME/.codex/skills/task-scope/scripts/scope_reply.py"`,
    max_output_tokens: 16000,
  });
  if (reply.exit_code === 0) return { state: "rendered", text: reply.output.trim() };
  if (reply.exit_code === 2 && reply.output.startsWith("**无法裁定。**")) {
    return { state: "invalid", text: reply.output.trim() };
  }
  return { state: "unavailable" };
};
