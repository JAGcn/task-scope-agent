"""Validate the judge's complete reply and render the scope decision."""

import json
import re
import sys


RESULT_VERSION = "TASK_SCOPE_RESULT_V1"
RESULT_KEYS = set("result_version verdict mode baseline_version status items missing_fields reason questions".split())
ITEM_KEYS = set("item_id category source_ids reason impact next_step".split())
QUESTION_KEYS = set("question_id text affects_item_ids source_ids reason".split())
STATUSES = {
    "READY": "可开始",
    "PARTIALLY_READY": "可先推进部分",
    "NEEDS_CONFIRMATION": "需先确认",
}
LABELS = {
    "DEFINE": {
        "OBJECTIVE": "目标",
        "DELIVERABLE": "交付物",
        "IN_SCOPE": "范围内",
        "NON_GOAL": "明确排除",
        "CONSTRAINT": "约束",
        "ACCEPTANCE_CONDITION": "验收条件",
        "ASSUMPTION": "暂用假设",
    },
    "CHANGE_REVIEW": {
        "IN_SCOPE": "范围内",
        "CHANGE_REQUIRED": "需变更",
        "OUT_OF_SCOPE": "范围外",
        "NEEDS_CONFIRMATION": "待确认",
    },
    "DELIVERY_REVIEW": {
        "SATISFIED": "已满足",
        "INSUFFICIENT_EVIDENCE": "证据不足",
        "OUTSIDE_CONFIRMED_SCOPE": "超出确认范围",
    },
}
FIELD_LABELS = {
    "packet_version": "案件包格式",
    "mode": "本轮审查类型",
    "active_request": "本轮要审查的事项",
    "confirmed_baseline": "已确认任务单",
    "baseline_version": "已确认任务单的版本",
    "candidate_items": "要审查的追加事项",
    "constraints": "已确认约束",
    "non_goals": "已确认的排除项",
    "deliverables": "已确认交付物",
    "acceptance_evidence": "实际交付或验收证据",
    "unresolved_facts": "仍需核实的事实",
    "sources": "事项依据",
    "source_ids": "事项依据",
    "items": "逐项裁定",
    "item_id": "事项对应关系",
    "questions": "要确认的问题",
    "missing_fields": "缺少的材料",
}
MODE_LABELS = {"DEFINE": "新任务定义", "CHANGE_REVIEW": "变更审查", "DELIVERY_REVIEW": "交付审查"}
PATH_PATTERN = re.compile(r"\$(?:\.[A-Za-z_][\w]*|\[\d+\])*")
SOURCE_MARKER = re.compile(r"\[(?:[UCAE]\d+\s*[,，、]\s*)*[UCAE]\d+\]")
FIELD_PATTERN = re.compile(r"\b(" + "|".join((*FIELD_LABELS, *MODE_LABELS)) + r")\b")


class ProtocolError(ValueError):
    pass


def require(condition, message):
    if not condition:
        raise ProtocolError(message)


def parse_object(raw):
    def unique_object(pairs):
        result = {}
        for key, value in pairs:
            require(key not in result, "裁定中有重复字段")
            result[key] = value
        return result

    def reject_constant(_):
        raise ProtocolError("裁定中有非法数值")

    result = json.loads(raw.strip(), object_pairs_hook=unique_object, parse_constant=reject_constant)
    require(isinstance(result, dict), "裁定必须是一个完整对象")
    return result


def nonempty(value):
    return isinstance(value, str) and bool(value.strip())


def refs(values, allowed):
    return isinstance(values, list) and all(nonempty(value) and value in allowed for value in values)


def record(value, keys):
    return isinstance(value, dict) and value.keys() == keys


def check_context(context):
    require(record(context, {"mode", "baseline_version", "source_ids", "candidates"}), "缺少本轮案件的校验信息")
    mode = context["mode"]
    version = context["baseline_version"]
    sources = context["source_ids"]
    candidates = context["candidates"]
    require(nonempty(mode) and mode in LABELS, "无法识别本轮审查类型")
    require(version is None if mode == "DEFINE" else nonempty(version), "缺少本轮案件的有效版本")
    require(isinstance(sources, list) and sources and all(map(nonempty, sources)), "本轮案件缺少来源")
    require(len(set(sources)) == len(sources), "本轮案件的来源对应关系重复")
    require(isinstance(candidates, dict) and all(nonempty(k) and nonempty(v) for k, v in candidates.items()),
            "本轮案件的候选事项对应关系无效")
    require(mode != "CHANGE_REVIEW" or candidates, "本轮案件缺少要审查的事项")


def check_result(context, result):
    require(record(result, RESULT_KEYS) and result["result_version"] == RESULT_VERSION, "裁定结果格式不符")
    require(nonempty(result["reason"]), "裁定缺少整体说明")
    items = result["items"]
    questions = result["questions"]
    missing = result["missing_fields"]
    require(isinstance(items, list) and isinstance(missing, list), "裁定的逐项结论或缺失材料格式不符")
    require(isinstance(questions, list) and len(questions) <= 3, "裁定的问题格式或数量不符")

    mode = context["mode"]
    version = context["baseline_version"]
    sources = set(context["source_ids"])
    item_ids = set()
    if result["verdict"] == "ADJUDICATED":
        require(result["mode"] == mode and result["baseline_version"] == version, "裁定与本轮审查类型或版本不符")
        status = result["status"]
        require(status in STATUSES if mode == "DEFINE" and isinstance(status, str) else mode != "DEFINE" and status is None,
                "裁定的任务状态不符")
        require(items and not missing, "裁定缺少逐项结论或仍缺少材料")
        for item in items:
            require(record(item, ITEM_KEYS) and nonempty(item["item_id"]), "逐项裁定格式不符")
            item_id = item["item_id"]
            require(item_id not in item_ids, "有事项被重复裁定")
            item_ids.add(item_id)
            require(nonempty(item["category"]) and item["category"] in LABELS[mode], "逐项裁定类别不符")
            require(item["source_ids"] and refs(item["source_ids"], sources), "有逐项裁定缺少有效依据")
            require(all(nonempty(item[key]) for key in ("reason", "impact", "next_step")),
                    "有逐项裁定缺少依据、影响或下一步")
        require(mode != "CHANGE_REVIEW" or item_ids == set(context["candidates"]),
                "裁定未能与本轮追加事项一一对应")
    else:
        require(result["verdict"] == "UNABLE_TO_JUDGE", "无法识别裁定的整体状态")
        require(result["mode"] in (None, mode) and result["baseline_version"] in (None, version),
                "无法裁定说明与本轮审查类型或版本不符")
        require(result["status"] is None and not items, "无法裁定的结果包含逐项结论")
        require(missing and all(nonempty(path) and PATH_PATTERN.fullmatch(path) for path in missing),
                "无法裁定的结果没有指出缺少哪项材料")

    question_ids = set()
    for question in questions:
        require(record(question, QUESTION_KEYS) and all(nonempty(question[k]) for k in ("question_id", "text", "reason")),
                "裁定问题的格式不符")
        require(question["question_id"] not in question_ids, "裁定中有重复问题")
        question_ids.add(question["question_id"])
        require(refs(question["affects_item_ids"], item_ids), "裁定问题引用了不存在的事项")
        require(refs(question["source_ids"], sources), "裁定问题引用了不存在的依据")


def field_name(path):
    if path == "$":
        return "完整的裁定输入"
    parts = path.split(".")[1:]
    for part in reversed(parts):
        key = part.split("[", 1)[0]
        if key in FIELD_LABELS:
            return FIELD_LABELS[key]
    return "相关任务材料"


def inline(value):
    return re.sub(r"([\\`*_\[\]<>|])", r"\\\1", " ".join(value.split()))


def visible(value):
    value = SOURCE_MARKER.sub("", value)
    value = PATH_PATTERN.sub(lambda match: field_name(match[0]) if match[0] != "$" else "$", value)
    value = FIELD_PATTERN.sub(lambda match: FIELD_LABELS.get(match[0], MODE_LABELS.get(match[0])), value)
    return inline(value)


def render(context, result):
    if result["verdict"] == "UNABLE_TO_JUDGE":
        missing = "、".join(dict.fromkeys(field_name(path) for path in result["missing_fields"]))
        lines = ["**无法裁定。** " + visible(result["reason"]), f"请补齐{missing}后重新裁定。"]
    else:
        status = STATUSES.get(result["status"])
        title = "**裁定完成。**" if status is None else f"**裁定完成 · {status}。**"
        version = result["baseline_version"]
        if version is not None:
            title += f" 基于 {inline(version)}。"
        lines = [title, visible(result["reason"])]

    subjects = {}
    for item in result["items"]:
        label = LABELS[result["mode"]][item["category"]]
        candidate = context["candidates"].get(item["item_id"]) if result["mode"] == "CHANGE_REVIEW" else None
        subjects[item["item_id"]] = inline(candidate) if candidate else visible(item["reason"])
        title = f"{inline(candidate)}｜{label}" if candidate else label
        lines.append(f"- **{title}**。{visible(item['reason'])} {visible(item['impact'])} 下一步：{visible(item['next_step'])}")

    if result["questions"]:
        lines.append("**需要确认**")
        for question in result["questions"]:
            linked = "、".join(subjects[item_id] for item_id in question["affects_item_ids"])
            suffix = f" 涉及{linked}。" if linked else ""
            lines.append(f"- {visible(question['text'])} {visible(question['reason'])}{suffix}")
    return "\n\n".join(lines)


def main():
    try:
        payload = parse_object(sys.stdin.read())
        require(record(payload, {"context", "response", "raw"}) and isinstance(payload["raw"], bool),
                "缺少本轮案件或原始裁定")
        context = payload["context"]
        check_context(context)
        require(nonempty(payload["response"]), "裁定组件未返回完整结果")
        response = parse_object(payload["response"])
        check_result(context, response)
        print(payload["response"].strip() if payload["raw"] else render(context, response))
        return 0
    except ProtocolError as error:
        print(f"**无法裁定。** {error}。请重新发起本轮裁定。")
    except (ValueError, RecursionError):
        print("**无法裁定。** 裁定组件的回复格式不完整。请重新发起本轮裁定。")
    return 2


if __name__ == "__main__":
    sys.exit(main())
